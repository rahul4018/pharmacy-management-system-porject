<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Total Sales</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        header {
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #4CAF50;
        }

        .sales-summary {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-bottom: 20px;
            font-size: 1.2em;
        }

        .sales-summary p {
            margin: 10px 0;
            padding: 10px;
            background-color: #f8f8f8;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            flex: 1 1 48%;
        }

        .filter-bar {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .filter-bar input[type="date"],
        .filter-bar input[type="text"],
        .filter-bar button {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }

        .filter-bar input[type="text"] {
            width: 200px;
        }

        .sales-details {
            overflow-x: auto;
        }

        .sales-details table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .sales-details th, .sales-details td {
            padding: 12px;
            text-align: left;
            cursor: pointer;
        }

        .sales-details th {
            background-color: #4CAF50;
            color: white;
            border: none;
        }

        .sales-details td {
            background-color: #f8f8f8;
            border: none;
            border-bottom: 1px solid #ddd;
        }

        .sales-details tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .sales-details tbody tr:hover {
            background-color: #eaeaea;
        }

        .chart-container {
            margin-top: 20px;
        }

        #sales-chart, #sales-line-chart, #sales-pie-chart {
            width: 100%;
            height: 300px;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pagination button {
            padding: 10px 20px;
            margin: 0 5px;
            border: none;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9em;
            color: #888;
        }

        .footer a {
            color: #4CAF50;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Modal Styling remains unchanged */
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Pharmacy Management System</h1>
            <nav>
                <ul>
                    <li><a href="dashboard.html">Dashboard</a></li>
                    <li><a href="inventory.html">Inventory</a></li>
                    <li><a href="sales.html">Sales</a></li>
                    <li><a href="reports.html">Reports</a></li>
                    <li><a href="settings.html">Settings</a></li>
                </ul>
            </nav>
        </header>
        <main>
            <h2>Total Sales</h2>
            <div class="sales-summary">
                <p>Total Sales: <span id="total-sales">$0</span></p>
                <p>Number of Transactions: <span id="num-transactions">0</span></p>
            </div>
            <div class="filter-bar">
                <input type="date" id="start-date">
                <input type="date" id="end-date">
                <input type="text" id="search" placeholder="Search...">
                <button onclick="filterSales()">Filter</button>
                <button onclick="openModal('add')">Add Transaction</button>
            </div>
            <div class="sales-details">
                <h3>Sales Details</h3>
                <table>
                    <thead>
                        <tr>
                            <th onclick="sortTable('date')">Date</th>
                            <th onclick="sortTable('customer')">Customer</th>
                            <th onclick="sortTable('amount')">Amount</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="sales-table-body">
                        <!-- Sales data will be inserted here by JavaScript -->
                    </tbody>
                </table>
            </div>
            <div class="pagination" id="pagination"></div>
            <div class="chart-container">
                <h3>Sales Chart</h3>
                <canvas id="sales-chart"></canvas>
                <canvas id="sales-line-chart"></canvas>
                <canvas id="sales-pie-chart"></canvas> <!-- Added canvas for the pie chart -->
            </div>
        </main>
        <footer class="footer">
            <p>&copy; 2024 Pharmacy Management System. <a href="about.html">About</a> | <a href="contact.html">Contact</a></p>
        </footer>
    </div>

    <!-- Modal for Add/Edit Transaction remains unchanged -->

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        let salesData = [
            { id: 1, date: '2024-06-01', customer: 'John Doe', amount: 50 },
            { id: 2, date: '2024-06-02', customer: 'Jane Smith', amount: 30 },
            { id: 3, date: '2024-06-03', customer: 'Bill Johnson', amount: 70 }
        ];

        document.addEventListener('DOMContentLoaded', function() {
            updateSalesSummary();
            populateSalesTable();
            renderCharts();
        });

        function updateSalesSummary() {
            const totalSalesElement = document.getElementById('total-sales');
            const numTransactionsElement = document.getElementById('num-transactions');
            let totalSales = 0;
            let numTransactions = salesData.length;

            salesData.forEach(sale => totalSales += sale.amount);

            totalSalesElement.textContent = `$${totalSales}`;
            numTransactionsElement.textContent = numTransactions;
        }

        function populateSalesTable() {
            const salesTableBody = document.getElementById('sales-table-body');
            while (salesTableBody.firstChild) {
                salesTableBody.removeChild(salesTableBody.firstChild);
            }

            salesData.forEach(sale => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${sale.date}</td>
                    <td>${sale.customer}</td>
                    <td>$${sale.amount}</td>
                    <td>
                        <button onclick="openModal('edit', ${sale.id})">Edit</button>
                        <button onclick="deleteTransaction(${sale.id})">Delete</button>
                    </td>
                `;
                salesTableBody.appendChild(row);
            });
        }

        function sortTable(key) {
            salesData.sort((a, b) => {
                const valA = a[key];
                const valB = b[key];

                if (key === 'amount') {
                    return valA - valB;
                }

                return valA.localeCompare(valB);
            });

            populateSalesTable();
        }

        function filterSales() {
            const startDate = document.getElementById('start-date').value;
            const endDate = document.getElementById('end-date').value;
            const searchQuery = document.getElementById('search').value.toLowerCase();
            const salesTableBody = document.getElementById('sales-table-body');

            const filteredData = salesData.filter(sale => {
                const saleDate = new Date(sale.date);
                const isWithinDateRange = (!startDate || new Date(startDate) <= saleDate) && (!endDate || new Date(endDate) >= saleDate);
                const matchesSearch = !searchQuery || sale.customer.toLowerCase().includes(searchQuery);
                return isWithinDateRange && matchesSearch;
            });

            while (salesTableBody.firstChild) {
                salesTableBody.removeChild(salesTableBody.firstChild);
            }

            let totalSales = 0;
            filteredData.forEach(sale => {
                totalSales += sale.amount;

                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${sale.date}</td>
                    <td>${sale.customer}</td>
                    <td>$${sale.amount}</td>
                `;
                salesTableBody.appendChild(row);
            });

            document.getElementById('total-sales').textContent = `$${totalSales}`;
            document.getElementById('num-transactions').textContent = filteredData.length;
        }

        function renderCharts() {
            const salesChart = document.getElementById('sales-chart').getContext('2d');
            new Chart(salesChart, {
                type: 'bar',
                data: {
                    labels: salesData.map(sale => sale.date),
                    datasets: [{
                        label: 'Sales Amount',
                        data: salesData.map(sale => sale.amount),
                        backgroundColor: '#4CAF50'
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            const salesLineChart = document.getElementById('sales-line-chart').getContext('2d');
            new Chart(salesLineChart, {
                type: 'line',
                data: {
                    labels: salesData.map(sale => sale.date),
                    datasets: [{
                        label: 'Sales Amount',
                        data: salesData.map(sale => sale.amount),
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            const salesPieChart = document.getElementById('sales-pie-chart').getContext('2d');
            new Chart(salesPieChart, {
                type: 'pie',
                data: {
                    labels: salesData.map(sale => sale.customer),
                    datasets: [{
                        label: 'Sales by Customer',
                        data: salesData.map(sale => sale.amount),
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.5)',
                            'rgba(54, 162, 235, 0.5)',
                            'rgba(255, 206, 86, 0.5)',
                            'rgba(75, 192, 192, 0.5)',
                            'rgba(153, 102, 255, 0.5)',
                            'rgba(255, 159, 64, 0.5)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        function openModal(mode, id = null) {
            const modal = document.getElementById('transactionModal');
            const modalTitle = document.getElementById('modal-title');
            const saveBtn = document.getElementById('save-btn');
            const dateInput = document.getElementById('modal-date');
            const customerInput = document.getElementById('modal-customer');
            const amountInput = document.getElementById('modal-amount');

            if (mode === 'add') {
                modalTitle.textContent = 'Add Transaction';
                saveBtn.onclick = saveTransaction;
                dateInput.value = '';
                customerInput.value = '';
                amountInput.value = '';
            } else {
                modalTitle.textContent = 'Edit Transaction';
                const transaction = salesData.find(sale => sale.id === id);
                dateInput.value = transaction.date;
                customerInput.value = transaction.customer;
                amountInput.value = transaction.amount;
                saveBtn.onclick = () => saveTransaction(id);
            }

            modal.style.display = 'block';
        }

        function closeModal() {
            const modal = document.getElementById('transactionModal');
            modal.style.display = 'none';
        }

        function saveTransaction(id = null) {
            const dateInput = document.getElementById('modal-date').value;
            const customerInput = document.getElementById('modal-customer').value;
            const amountInput = document.getElementById('modal-amount').value;

            if (id) {
                const transaction = salesData.find(sale => sale.id === id);
                transaction.date = dateInput;
                transaction.customer = customerInput;
                transaction.amount = parseFloat(amountInput);
            } else {
                const newTransaction = {
                    id: salesData.length ? Math.max(...salesData.map(sale => sale.id)) + 1 : 1,
                    date: dateInput,
                    customer: customerInput,
                    amount: parseFloat(amountInput)
                };
                salesData.push(newTransaction);
            }

            closeModal();
            updateSalesSummary();
            populateSalesTable();
            renderCharts();
        }

        function deleteTransaction(id) {
            salesData = salesData.filter(sale => sale.id !== id);
            updateSalesSummary();
            populateSalesTable();
            renderCharts();
        }

        window.onclick = function(event) {
            const modal = document.getElementById('transactionModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>


