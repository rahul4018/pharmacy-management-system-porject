<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - Medication Management</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #343a40;
        }

        header {
            background-color: #007bff;
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
        }

        nav ul li {
            margin-left: 15px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            font-size: 18px;
            transition: color 0.3s;
        }

        nav ul li a:hover {
            color: #f0f0f0;
        }

        main {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .dashboard-links {
            margin-top: 50px;
            text-align: center;
        }

        .dashboard-links h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #343a40;
        }

        .dashboard-links a {
            display: block;
            padding: 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s;
            font-size: 18px;
            margin-bottom: 10px;
        }

        .dashboard-links a:hover {
            background-color: #0056b3;
        }

        footer {
            text-align: center;
            padding: 20px 0;
            background-color: #007bff;
            color: #fff;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>User Dashboard - Medication Management</h1>
        <nav>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="custprof.html">Profile</a></li>
                <li><a href="frontpage.html">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="dashboard-links">
            <h2>What would you like to do?</h2>
            <a href="usermed.html" id="order-medicines">Order Medicines</a>
            <a href="appointments.html" id="schedule-appointments">Schedule Appointments</a>
            <a href="uploadprescription.html" id="upload-prescription">Upload Prescription</a>
            <a href="custprof.html" id="manage-profile">Manage Profile</a>
            <a href="myord.html" id="my-orders">My Orders</a>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Medication Management System. All rights reserved.</p>
    </footer>

    <script>
        // JavaScript for user dashboard functionality
        document.addEventListener('DOMContentLoaded', function () {
            // Add event listeners to dashboard links
            document.getElementById('order-medicines').addEventListener('click', function () {
                // Logic to navigate to order medicines page
                // Assuming addmed.html exists in the same directory
                window.location.href = 'addmed.html';
            });

            document.getElementById('schedule-appointments').addEventListener('click', function () {
                // Logic to navigate to schedule appointments page
                window.location.href = 'appointments.html'; // Replace with the actual URL
            });

            document.getElementById('upload-prescription').addEventListener('click', function () {
                // Logic to navigate to upload prescription page
                window.location.href = 'uploadprescription.html'; // Replace with the actual URL
            });

            document.getElementById('manage-profile').addEventListener('click', function () {
                // Logic to navigate to manage profile page
                window.location.href = 'custprof.html'; // Replace with the actual URL
            });

            document.getElementById('my-orders').addEventListener('click', function () {
                // Logic to navigate to my orders page
                window.location.href = 'myord.html'; // Replace with the actual URL
            });
        });
    </script>
</body>
</html>
