<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - PharmaExpect</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #5bbf88; /* Softer background color for a calming effect */
    }

    .container {
      max-width: 600px;
      margin: 50px auto;
      background-color: #ffffff;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
      color: #040e18;
      font-size: 28px;
    }

    form {
      display: grid;
      grid-gap: 20px;
    }

    label {
      font-weight: bold;
      color: #333;
    }

    input[type="text"],
    input[type="email"],
    textarea {
      width: 100%;
      padding: 14px;
      border: 1px solid #cda3a3;
      border-radius: 8px;
      font-size: 16px;
      transition: border-color 0.3s ease-in-out;
    }

    input[type="text"]:focus,
    input[type="email"]:focus,
    textarea:focus {
      outline: none;
      border-color: #4b7cb1;
    }

    textarea {
      resize: vertical;
      min-height: 100px;
    }

    button[type="submit"] {
      background-color: #062342;
      color: #faf9f9;
      border: none;
      border-radius: 8px;
      padding: 14px 24px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease-in-out;
      align-self: center; /* Center align the button */
    }

    button[type="submit"]:hover {
      background-color: #3bda5d;
    }

    #thank-you {
      display: none;
      text-align: center;
      margin-top: 20px;
    }

    #thank-you h1 {
      color: #007bff;
      font-size: 24px;
    }

    #thank-you p {
      color: #333;
      font-size: 16px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Contact Us - PharmaExpect</h1>
    <form id="contact-form" action="submit.php" method="post">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" placeholder="Enter your name" required>

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" placeholder="Enter your email" required>

      <label for="message">Message:</label>
      <textarea id="message" name="message" rows="4" placeholder="Enter your message" required></textarea>

      <button type="submit">Submit</button>
    </form>
    <div id="thank-you">
      <h1>Thank You for Contacting Us</h1>
      <p>We have received your message and will get back to you shortly.</p>
    </div>
  </div>

  <script>
    document.getElementById('contact-form').addEventListener('submit', function(event) {
      event.preventDefault();
      document.getElementById('thank-you').style.display = 'block';
      setTimeout(function() {
        document.getElementById('thank-you').style.display = 'none';
      }, 3000); 
      this.reset();
    });
  </script>
</body>
</html>
