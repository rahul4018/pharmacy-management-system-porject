<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medication List</title>
    <style>
        /* Your existing styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        nav ul li a:hover {
            text-decoration: underline;
        }

        main {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        section {
            margin-bottom: 40px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        section h2 {
            margin-top: 0;
            color: #007bff;
        }

        .medication {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .medication:last-child {
            border-bottom: none;
        }

        .medication h3 {
            margin: 0;
            color: #007bff;
        }

        .medication p {
            margin: 5px 0;
        }

        .medication button {
            padding: 5px 10px;
            background-color: #dc3545;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        .medication button:hover {
            background-color: #c82333;
        }

        .order-id {
            font-size: 20px;
            font-weight: bold;
            color: #b70e0e;
            margin-bottom: 5px;
        }

        .order-details {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }
    </style>
</head>
<body>
    <header>
        <h1>Medication Management System</h1>
        <nav>
            <ul>
                <li><a href="custo.html">Home</a></li>
                <li><a href="medications.html">Medications</a></li>
                <li><a href="#">Categories</a></li>
                <li><a href="#">Orders</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="medication-list">
            <h2>Added Medications</h2>
            <div id="medicationsContainer"></div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Medication Management System. All rights reserved.</p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const medicationsContainer = document.getElementById('medicationsContainer');
            const medications = JSON.parse(localStorage.getItem('medications')) || [];

            if (medications.length === 0) {
                medicationsContainer.innerHTML = '<p>No medications added yet. <a href="addmed.html">Start Ordering</a></p>';
                return;
            }

            medications.forEach((medication, index) => {
                const medicationDiv = document.createElement('div');
                medicationDiv.classList.add('medication');

                medicationDiv.innerHTML = `
                    <div>
                        <h3>${medication.name}</h3>
                        <p><strong>Price:</strong> $${medication.price}</p>
                        <p><strong>Category:</strong> ${medication.category}</p>
                        <p><strong>Quantity:</strong> ${medication.quantity}</p>
                        <p><strong>Description:</strong> ${medication.description}</p>
                        <p><strong>Manufacturer:</strong> ${medication.manufacturer}</p>
                        <p><strong>Prescription File:</strong> ${medication.prescriptionFile}</p>
                    </div>
                    <div class="order-details">
                        <p class="order-id">Order ID: ${medication.orderId}</p>
                        <button onclick="deleteMedication(${index})">Delete</button>
                    </div>
                `;

                medicationsContainer.appendChild(medicationDiv);
            });
        });

        function deleteMedication(index) {
            const medications = JSON.parse(localStorage.getItem('medications')) || [];
            medications.splice(index, 1);
            localStorage.setItem('medications', JSON.stringify(medications));
            location.reload();
        }
    </script>
</body>
</html>
