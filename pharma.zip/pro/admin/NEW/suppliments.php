<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medicines Catalog</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .header, .footer {
            text-align: center;
            padding: 20px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #ccc;
        }

        .header {
            margin-bottom: 20px;
        }

        .navbar {
            display: flex;
            justify-content: center;
            background-color: #007bff;
            padding: 10px;
        }

        .navbar a {
            color: white;
            padding: 14px 20px;
            text-decoration: none;
            text-align: center;
            position: relative;
        }

        .navbar a:hover {
            background-color: #0056b3;
        }

        .navbar .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown {
            position: relative;
            display: inline-block;
            padding: 14px 20px; /* Add this line */
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f8f9fa;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            top: 100%; /* Align dropdown below the navbar */
            left: 0;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
        }

        .dropdown-content a:hover {
            background-color: #ddd;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .catalog {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .medicine {
            width: 300px;
            margin: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .medicine img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .description {
            margin-top: 10px;
        }

        .info {
            margin-top: 10px;
        }

        button {
            margin-top: 10px;
            padding: 5px 10px;
            border: none;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
            border-radius: 3px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .testimonials {
            text-align: center;
            margin: 20px 0;
            padding: 20px;
            background-color: #f8f9fa;
            border-top: 1px solid #ccc;
            border-bottom: 1px solid #ccc;
        }

        .testimonials h2 {
            margin-bottom: 20px;
        }

        .testimonials p {
            margin: 10px;
            display: inline-block;
        }

        .footer {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Welcome to Our Pharmacy</h1>
        <p>Your trusted source for medications and health products</p>
    </div>

    <div class="navbar">
        <a href="#home">Home</a>
        <a href="#catalog">Catalog</a>
        <div class="dropdown">
            <a href="#categories" class="dropbtn">Categories</a>
            <div class="dropdown-content">
                <a href="#supplements">Supplements</a>
                <a href="#personal-care">Personal Care</a>
                <a href="#vitamins">Vitamins & Minerals</a>
                <a href="#herbal">Herbal Remedies</a>
                <a href="#baby-care">Baby Care</a>
                <a href="#medical-devices">Medical Devices</a>
                <a href="#skin-care">Skin Care</a>
                <a href="#weight-loss">Weight Loss</a>
                <a href="#first-aid">First Aid</a>
                <a href="#dietary">Dietary Supplements</a>
                <a href="#pain-relief">Pain Relief</a>
                <a href="#allergy">Allergy Relief</a>
                <a href="#cold-flu">Cold & Flu</a>
                <a href="#sexual-health">Sexual Health</a>
            </div>
        </div>
        <a href="#testimonials">Testimonials</a>
        <a href="#contact">Contact Us</a>
    </div>

    <div class="catalog">
        <!-- Medicines will be displayed here -->
    </div>

    <div class="testimonials" id="testimonials">
        <h2>Customer Testimonials</h2>
        <p>"Great service and fast delivery!" - Jane Doe</p>
        <p>"Wide range of products and excellent customer support." - John Smith</p>
        <p>"Highly recommend this pharmacy for all your needs." - Mary Johnson</p>
    </div>

    <div class="footer">
        <p>&copy; 2024 Our Pharmacy. All rights reserved.</p>
    </div>

    <script>
        // Add event listeners to Add to Cart buttons
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', () => {
                // Implement adding to cart functionality here
                console.log('Added to cart');
            });
        });

        // Add event listeners to Order Now buttons
        document.querySelectorAll('.order-now').forEach(button => {
            button.addEventListener('click', () => {
                // Implement ordering functionality here
                console.log('Ordered');
            });
        });
    </script>
</body>
</html>
