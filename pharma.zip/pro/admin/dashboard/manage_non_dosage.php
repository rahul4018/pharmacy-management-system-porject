<?php 
session_start();

require "includes/conn.php";

// Initialize variables
$invoice = '';
$total = 0;
$payment = 0;
$payment_change = 0;

if (isset($_GET['invoice'])) {
    $invoice = mysqli_real_escape_string($conn, $_GET['invoice']);

    // Retrieve sales data
    $sql = "SELECT * FROM sales WHERE invoice = '$invoice'";
    $res = mysqli_query($conn, $sql);

    if ($res && mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);

        $total = $row['total'] ?? 0;
        $payment = $row['payment'] ?? 0;
        $payment_change = $row['payment_change'] ?? 0;
    } else {
        $_SESSION['error'] = "No sales data found for the given invoice.";
    }
}
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<?php 
require "includes/head.php";
?>

<body>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <?php require "includes/header.php"?>
        <?php require "includes/aside.php";?>
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Receipt</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-md-flex align-items-center">
                                    <div>
                                        <h4 class="card-title">Receipt</h4>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <h5>Invoice No: <?php echo htmlspecialchars($invoice); ?></h5>
                                        <p>Total Amount: <?php echo number_format($total, 2); ?></p>
                                        <p>Amount Paid: <?php echo number_format($payment, 2); ?></p>
                                        <p>Change: <?php echo number_format($payment_change, 2); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <a href="index.php" class="btn btn-primary">Back to Home</a>
                                <a href="print_receipt.php?invoice=<?php echo urlencode($invoice); ?>" class="btn btn-success">Print Receipt</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer text-center">
                All Rights Reserved 
            </footer>
        </div>
    </div>
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="dist/js/app-style-switcher.js"></script>
    <script src="dist/js/waves.js"></script>
    <script src="dist/js/sidebarmenu.js"></script>
    <script src="dist/js/custom.js"></script>
    <script src="assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="dist/js/pages/dashboards/dashboard1.js"></script>
</body>

</html>
