<?php 
session_start();

if (isset($_POST['submit'])) {
    require "includes/conn.php";

    $patient_no = mysqli_real_escape_string($conn, $_POST['patient_no']);
    $amount_given = mysqli_real_escape_string($conn, $_POST['amount_given']);
    $invoice = mysqli_real_escape_string($conn, $_POST['invoice']);
    $invoice_due = mysqli_real_escape_string($conn, $_POST['invoice_due']);
    $change = $amount_given - $invoice_due;

    $sql = "UPDATE sales SET
            total = '$invoice_due',
            payment = '$amount_given',
            payment_change = '$change'
            WHERE invoice = '$invoice'";
    
    $res = mysqli_query($conn, $sql);

    if ($res) {
        $sql2 = "UPDATE sales_order SET
                 status = '1'
                 WHERE invoice = '$invoice'";
        $res2 = mysqli_query($conn, $sql2);
        
        if ($res2) {
            $sql3 = "UPDATE patients SET
                     status = '1'
                     WHERE patient_no = '$patient_no'";
            $res3 = mysqli_query($conn, $sql3);
            
            if ($res3) {
                $_SESSION['sessioninvoice'] = $invoice;
                $_SESSION['sessionpaymentid'] = $patient_no;
                $_SESSION['sessionchange'] = $change; // Storing the change in session
                header("Location: receipt.php");
                exit();
            } else {
                $_SESSION['failed_price'] = "<div class='alert alert-danger'>Failed to Update Patient Status</div>";
                header("Location: ../receipt.php");
                exit();
            }
        } else {
            $_SESSION['failed_price'] = "<div class='alert alert-danger'>Failed to Update Sales Order Status</div>";
            header("Location: ../receipt.php");
            exit();
        }
    } else {
        $_SESSION['failed_price'] = "<div class='alert alert-danger'>Failed to Update Sales</div>";
        header("Location: ../receipt.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Maven+Pro&display=swap');

        body {
            font-family: 'Maven Pro', sans-serif;
            background-color: #f5f5f5;
        }

        hr {
            color: #0000004f;
            margin-top: 5px;
            margin-bottom: 5px;
        }

        .add td {
            color: #c5c4c4;
            text-transform: uppercase;
            font-size: 12px;
        }

        .content {
            font-size: 14px;
        }
    </style>
    <script language="javascript">
        function Clickheretoprint() { 
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,"; 
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25"; 
            var content_value = document.getElementById("content").innerHTML; 

            var docprint = window.open("", "", disp_setting); 
            docprint.document.open(); 
            docprint.document.write('</head><body onLoad="self.print()" style="width: 800px; font-size: 13px; font-family: arial;">');          
            docprint.document.write(content_value); 
            docprint.document.close(); 
            docprint.focus(); 
        }
    </script>
</head>
<body>
<div align="left" class="px-5 mb-5">
    <br>
    <a href="index.php" class="btn btn-success">Back</a>
</div>
<div class="container mt-5 mb-3">
    <div class="row d-flex justify-content-center">
        <div class="col-md-8">
            <div class="card print-container">
                <div class="d-flex flex-row p-2">
                    <img src="assets/images/logo-icon.png" width="48">
                    <div class="d-flex flex-column">
                        <span class="font-weight-bold">Receipt</span>
                    </div>
                </div>
                <div align="center">
                    <i>This is the start of this legal receipt</i>
                </div>
                <hr>
                <div class="table-responsive p-2">
                    <div align="center" class="align-items-center">
                        <b>PHARMACY</b><br>
                        <b>P.O Box 108-10100</b><br>
                        <b>Nyeri</b><br>
                        <b>0707 000 100</b><br>
                    </div>
                </div>
                <hr>
                <div class="products p-2">
                    <h5>Medicine Prescribed</h5>
                    <table class="table table-borderless">
                        <tbody>
                            <tr class="add">
                                <td>Medicine Name</td>
                                <td>Quantity</td>
                                <td>Price</td>
                                <td class="text-center">Total</td>
                            </tr>
                            <?php 
                            require "includes/conn.php";	
                            $invoice = $_SESSION['sessioninvoice'];
                            $change = isset($_SESSION['sessionchange']) ? $_SESSION['sessionchange'] : 0;

                            $sql = "SELECT SUM(amount) as 'amount' FROM sales_order WHERE invoice ='$invoice'";
                            $res = mysqli_query($conn, $sql);
                            $data = mysqli_fetch_array($res);

                            $sql = "SELECT * FROM sales WHERE invoice = '$invoice'";
                            $res = mysqli_query($conn, $sql);

                            if ($res) {
                                $count = mysqli_num_rows($res);
                                if ($count > 0) {
                                    while ($rows = mysqli_fetch_assoc($res)) {
                                        $medicine_name = $rows['medicine_name'];
                                        $price = $rows['price'];
                                        $qty = $rows['qty'];
                                        $medicine_subtotal_price = $qty * $price;
                                        ?>
                                        <tr class="content">
                                            <td><?php echo $medicine_name; ?></td>
                                            <td><?php echo $qty; ?> X</td>
                                            <td><?php echo $price; ?></td>
                                            <td class="text-center"><?php echo $medicine_subtotal_price; ?></td>
                                        </tr>
                                        <?php
                                    }
                                }
                            }
                            ?>
                            <tr>
                                <td></td>
                                <td></td>
                                <td><b>Subtotal</b></td>
                                <td><?php echo $data['amount']; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <hr>
                <div class="products p-2">
                    <table class="table table-borderless">
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><h5>Total:</h5></td>
                                <td><h5><?php echo $data['amount']; ?>.00</h5><br></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><h5>Cash:</h5></td>
                                <td><h5><?php echo $data['amount'] + $change; ?>.00</h5><br></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><h5>Balance:</h5></td>
                                <td><h5><?php echo $change; ?>.00</h5><br></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="address p-2">
                    <div align="center">
                        <i>This is the end of this legal receipt</i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div align="center">
        <button class="btn btn-success" onclick="Clickheretoprint()">Print this page</button>
    </div>
</div>
</body>
</html>
