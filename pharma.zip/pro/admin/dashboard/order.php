<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $address = htmlspecialchars($_POST['address']);
    $phone = htmlspecialchars($_POST['phone']);
    $product = htmlspecialchars($_POST['product']);
    $payment_method = htmlspecialchars($_POST['payment_method']);

    if ($payment_method == "COD") {
        // Process the COD order
        echo "<h1>Order Summary</h1>";
        echo "Name: " . $name . "<br>";
        echo "Address: " . $address . "<br>";
        echo "Phone: " . $phone . "<br>";
        echo "Product: " . $product . "<br>";
        echo "Payment Method: Cash on Delivery<br>";

        // You can add code here to save the order details to a database

        echo "<p>Thank you for your order! Please be prepared to pay cash upon delivery.</p>";
    } else {
        echo "Invalid payment method.";
    }
} else {
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Form</title>
</head>
<body>
    <h1>Place Your Order</h1>
    <form action="" method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="address">Address:</label>
        <input type="text" id="address" name="address" required><br><br>

        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" required><br><br>

        <label for="product">Product:</label>
        <input type="text" id="product" name="product" required><br><br>

        <input type="hidden" name="payment_method" value="COD">
        
        <button type="submit">Place Order</button>
    </form>
</body>
</html>

<?php
}
?>
